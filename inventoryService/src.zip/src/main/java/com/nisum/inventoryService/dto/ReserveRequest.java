package com.nisum.inventoryService.dto;

public class ReserveRequest {
    private Integer orderId;
    private String sku;
    private Integer categoryId;
    private Integer reservedQty;

    // Getters
    public Integer getOrderId() {
        return orderId;
    }

    public String getSku() {
        return sku;
    }

    public Integer getCategoryId() {
        return categoryId;
    }

    public Integer getReservedQty() {
        return reservedQty;
    }

    // Setters
    public void setOrderId(Integer orderId) {
        this.orderId = orderId;
    }

    public void setSku(String sku) {
        this.sku = sku;
    }

    public void setCategoryId(Integer categoryId) {
        this.categoryId = categoryId;
    }

    public void setReservedQty(Integer reservedQty) {
        this.reservedQty = reservedQty;
    }
}
