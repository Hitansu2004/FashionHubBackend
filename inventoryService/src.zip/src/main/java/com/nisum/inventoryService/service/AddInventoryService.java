package com.nisum.inventoryService.service;

import com.nisum.inventoryService.dto.InventoryDTO;
import java.util.List;

public interface AddInventoryService {

    InventoryDTO addInventory(InventoryDTO dto); // ✅ Must match
    List<InventoryDTO> getAllInventory();
}
