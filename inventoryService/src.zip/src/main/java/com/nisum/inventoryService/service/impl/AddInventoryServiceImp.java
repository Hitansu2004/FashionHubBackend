package com.nisum.inventoryService.service;

import com.nisum.inventoryService.dao.Inventory;
import com.nisum.inventoryService.dto.InventoryDTO;
import com.nisum.inventoryService.repository.AddInventoryRepo;
import com.nisum.inventoryService.utils.MapperUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class AddInventoryServiceImp implements AddInventoryService {

    @Autowired
    private AddInventoryRepo addInventoryRepo;

    @Autowired
    private MapperUtil mapperUtil;

    @Override
    public InventoryDTO addInventory(InventoryDTO dto) {
        if (addInventoryRepo.existsBySku(dto.getSku())) {
            throw new IllegalArgumentException("SKU already exists");
        }

        Inventory inventory = mapperUtil.mapToInventory(dto);
        Inventory saved = addInventoryRepo.save(inventory);
        return mapperUtil.mapToInventoryDto(saved);
    }

    @Override
    public List<InventoryDTO> getAllInventory() {
        return addInventoryRepo.findAll().stream()
                .map(mapperUtil::mapToInventoryDto)
                .collect(Collectors.toList());
    }
}
